<?php

require "config/conex.php";

$cuantas = $_POST["cuantas"];
$tipo = $_POST["tipo"];
$total_venta = 0; 

if ($tipo == 1) {
    $tipo = 100;
    $total_venta = $tipo * $cuantas;
}
if ($tipo == 2) {
    $tipo = 1000;
    $total_venta = $tipo * $cuantas;
}


$sql = "INSERT INTO parcial2(cuantas, tipo, total_venta) 
        VALUES ($cuantas, '$tipo', $total_venta)";


if ($dbh->query($sql)) {
    echo "Su cantidad es $cuantas <br>";
    echo "Su tipo de regalo es $tipo <br>";
    echo "Su total de venta es de $total_venta <br>";
} else {
    echo "Error en la inserción del obsequio";
}
?>