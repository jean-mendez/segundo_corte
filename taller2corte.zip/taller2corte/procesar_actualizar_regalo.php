<?php
require "config/conex.php"; 


if (isset($_POST["id"], $_POST["cuantas"], $_POST["tipo"])) {
    $id = $_POST["id"];
    $cuantas = $_POST["cuantas"];
    $tipo = $_POST["tipo"];
    $total_venta = 0;

    
    $sql = "UPDATE parcial2 SET cuantas = ?, tipo = ?, total_venta = ? WHERE id = ?";
    $stmt = $dbh->prepare($sql);
    
    
    if ($stmt->execute([$id, $cuantas, $tipo, $total_venta, ])) {
        echo "Nota actualizada correctamente.";
    } else {
        echo "No se pudo realizar la modificación.";
    }
} else {
    echo "Faltan datos obligatorios del formulario.";
}
?>
