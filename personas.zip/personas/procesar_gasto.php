<?php
//paso 1 conectar
require "config/conex.php";

//paso 2 capturar variable
$id = $_POST["id"];
$gasto = $_POST["gasto"];

//paso 3 sentencia
$sql= "UPDATE clientes
SET
saldo=saldo-".$gasto."
WHERE id=".$id." ";

//paso 4 la decision

if ($dbh-> query($sql))
{
    echo "gasto correctamente guardado";
}else
{
    echo "error de gasto";
}
?>