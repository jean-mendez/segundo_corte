<?php
//paso 1
require "config/conex.php";

//paso 2
$id = $_POST["id"];
$nombre = $_POST["nombre"];
$celular = $_POST["celular"];

//paso 3
$sql="UPDATE clientes
SET
nombre='".$nombre."',
celular='".$celular."'
WHERE
id=".$id."";

//paso 4
if($dbh -> query($sql))
{
    echo "persona actualizada correctamente";
}
else{
    echo "no se pudo realizar la actualizacion";
}
?>